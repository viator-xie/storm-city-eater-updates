extends "res://scripts/standalone_level_safe_boot_v4.gd"

const ARENA_MANAGER_V2_SCRIPT = preload("res://scripts/tornado_battle_manager_v2.gd")

func _start_vortex_arena() -> void :
	_arena_manager = ARENA_MANAGER_V2_SCRIPT.new()
	_arena_manager.name = "VortexArenaManager"
	add_child(_arena_manager)
	_arena_manager.call("setup", tornado, map_node, _tokyo_world_items_runtime)
	var target: = int(_arena_manager.call("get_target_enemy_count")) if _arena_manager.has_method("get_target_enemy_count") else 0
	print("TOKYO_VORTEX_ARENA_5519_STARTED enemies=%d pooled_death=1 world_health=1" % target)
