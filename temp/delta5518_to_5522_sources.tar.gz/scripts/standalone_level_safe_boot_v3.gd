extends "res://scripts/standalone_level_safe_boot_v2.gd"




const TOKYO_SPARSE_ITEMS_V2_SCRIPT = preload("res://scripts/tokyo_sparse_item_runtime_v3.gd")

func _ensure_tokyo_runtimes() -> void :
	_tokyo_core_runtime = _resolve_or_create_runtime("TokyoCoreRuntime", TOKYO_CORE_SCRIPT)
	_tokyo_collision_runtime = _resolve_or_create_runtime("TokyoBuildingCollision", TOKYO_COLLISION_SCRIPT)

	_tokyo_detail_runtime = get_node_or_null("/root/TokyoSceneDetail")
	_disable_dense_runtime(_tokyo_detail_runtime, "detail")
	_tokyo_detail_runtime = null

	_tokyo_coverage_runtime = get_node_or_null("/root/TokyoPropCoverage")
	_disable_dense_runtime(_tokyo_coverage_runtime, "coverage")
	var old_world_items: = get_node_or_null("/root/TokyoWorldItems")
	_disable_dense_runtime(old_world_items, "world_items")

	_tokyo_world_items_runtime = _create_local_runtime("TokyoSparseArenaItems", TOKYO_SPARSE_ITEMS_V2_SCRIPT)
	print("TOKYO_ARENA_5519_RUNTIME_READY concurrent_pull=1 immediate_food=1 stable_name=1 single_sparse_runtime=1 active_limit=172")
