extends "res://scripts/tornado_enemy.gd"

const HEALTH_BAR_MAX_DISTANCE_M: = 260.0
const HEALTH_BAR_BASE_WIDTH: = 2.8
const HEALTH_BAR_MIN_WORLD_WIDTH: = 3.0
const HEALTH_BAR_MAX_WORLD_WIDTH: = 7.5

var health_bar_root: Node3D = null
var health_bar_back: MeshInstance3D = null
var health_bar_fill: MeshInstance3D = null

func _ready() -> void :
	super._ready()
	_build_health_bar()

func _build_health_bar() -> void :
	health_bar_root = Node3D.new()
	health_bar_root.name = "EnemyHealthBar"
	add_child(health_bar_root)
	health_bar_back = MeshInstance3D.new()
	health_bar_back.name = "HealthBack"
	var back_mesh: = BoxMesh.new()
	back_mesh.size = Vector3(HEALTH_BAR_BASE_WIDTH, 0.2, 0.055)
	var back_mat: = StandardMaterial3D.new()
	back_mat.albedo_color = Color(0.035, 0.045, 0.05, 0.92)
	back_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	back_mesh.material = back_mat
	health_bar_back.mesh = back_mesh
	health_bar_back.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	health_bar_root.add_child(health_bar_back)
	health_bar_fill = MeshInstance3D.new()
	health_bar_fill.name = "HealthFill"
	var fill_mesh: = BoxMesh.new()
	fill_mesh.size = Vector3(HEALTH_BAR_BASE_WIDTH - 0.16, 0.125, 0.072)
	var fill_mat: = StandardMaterial3D.new()
	fill_mat.albedo_color = Color(0.92, 0.16, 0.1, 1.0)
	fill_mat.emission_enabled = true
	fill_mat.emission = Color(0.3, 0.015, 0.005, 1.0)
	fill_mat.emission_energy_multiplier = 0.45
	fill_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fill_mesh.material = fill_mat
	health_bar_fill.mesh = fill_mesh
	health_bar_fill.position.z = -0.014
	health_bar_fill.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	health_bar_root.add_child(health_bar_fill)
	_update_health_bar()

func _physics_process(delta):
	super._physics_process(delta)
	_update_health_bar()

func _update_health_bar() -> void :
	if health_bar_root == null or not is_instance_valid(health_bar_root):
		return
	var should_show: = combat_alive
	if should_show and player_ref != null and is_instance_valid(player_ref):
		var flat: = global_position - player_ref.global_position
		flat.y = 0.0
		should_show = flat.length_squared() <= HEALTH_BAR_MAX_DISTANCE_M * HEALTH_BAR_MAX_DISTANCE_M
	health_bar_root.visible = should_show
	if not should_show:
		return
	var camera: = get_viewport().get_camera_3d()
	if camera != null and is_instance_valid(camera):
		health_bar_root.look_at(camera.global_position, Vector3.UP, true)
	var world_width: = clampf(visual_radius * 0.72, HEALTH_BAR_MIN_WORLD_WIDTH, HEALTH_BAR_MAX_WORLD_WIDTH)
	var width_scale: = world_width / HEALTH_BAR_BASE_WIDTH
	health_bar_back.scale.x = width_scale
	var ratio: = clampf(health / maxf(1.0, max_health), 0.0, 1.0)
	health_bar_fill.scale.x = width_scale * ratio
	health_bar_fill.position.x = - (HEALTH_BAR_BASE_WIDTH - 0.16) * width_scale * (1.0 - ratio) * 0.5
	health_bar_root.position = Vector3(0.0, maxf(3.8, visual_radius * 1.12 + 2.0), 0.0)

func reset_after_defeat(spawn_position: Vector3, restart_mass: = 12.0) -> void :
	super.reset_after_defeat(spawn_position, restart_mass)
	behavior_mode = "wander"
	behavior_target = spawn_position
	food_target = null
	decision_clock = 0.0
	chase_timer = 0.0
	chase_cooldown = rng.randf_range(3.0, 7.0)
	blocked_timer = 0.0
	_pick_wander_target()
	_update_health_bar()
	print("TORNADO_ENEMY_REUSED name=%s mass=%.1f hp=%.1f pooled_death=1" % [actor_name, mass, max_health])

func has_world_health_bar() -> bool:
	return health_bar_root != null and is_instance_valid(health_bar_root) and health_bar_fill != null and is_instance_valid(health_bar_fill)
