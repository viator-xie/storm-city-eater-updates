extends "res://scripts/tokyo_sparse_item_runtime_v2.gd"

const ARENA_MAX_ACTIVE_ITEMS: = 172

func _process(delta: float) -> void :
	if _city == null or not is_instance_valid(_city) or _focus == null or not is_instance_valid(_focus):
		return
	_clock -= delta
	if _clock > 0.0:
		return
	_clock = FAST_REPLENISH_SECONDS
	_cleanup_invalid()
	_recycle_far_grounded()
	_ensure_immediate_quota(_focus, PLAYER_INNER_TARGET, PLAYER_INNER_KEEP_M, PLAYER_INNER_SPAWN_MIN_M, PLAYER_INNER_SPAWN_MAX_M, PLAYER_INNER_BATCH, true)
	_ensure_local_quota(_focus, PLAYER_TOTAL_TARGET, PLAYER_TOTAL_KEEP_M, PLAYER_OUTER_SPAWN_MIN_M, PLAYER_OUTER_SPAWN_MAX_M, PLAYER_OUTER_BATCH, true)
	for enemy in _valid_enemy_foci():
		if _active_count() >= ARENA_MAX_ACTIVE_ITEMS:
			break
		_ensure_immediate_quota(enemy, ENEMY_INNER_TARGET, ENEMY_INNER_KEEP_M, ENEMY_INNER_SPAWN_MIN_M, ENEMY_INNER_SPAWN_MAX_M, ENEMY_INNER_BATCH, false)
		_ensure_local_quota(enemy, ENEMY_TOTAL_TARGET, ENEMY_TOTAL_KEEP_M, ENEMY_OUTER_SPAWN_MIN_M, ENEMY_OUTER_SPAWN_MAX_M, ENEMY_OUTER_BATCH, false)
	_refresh_actor_prop_caches()

func _ensure_immediate_quota(focus: Node3D, target: int, keep_radius: float, spawn_min: float, spawn_max: float, batch_limit: int, player_priority: bool) -> void :
	if focus == null or not is_instance_valid(focus): return
	var missing: = maxi(0, target - _count_near_edible(focus, keep_radius, 1))
	var to_spawn: = mini(missing, batch_limit)
	if player_priority and to_spawn > 0: _make_room_for_player(to_spawn, _focus_level(focus))
	var made: = 0
	var guard: = 0
	while made < to_spawn and _active_count() < ARENA_MAX_ACTIVE_ITEMS and guard < to_spawn * 30 + 60:
		guard += 1
		var profile: = _random_immediate_profile()
		var placement: = _open_position_for_focus(focus.global_position, profile, spawn_min, spawn_max)
		if placement.is_empty(): continue
		var prop: = _spawn_profile(profile, placement)
		if prop != null:
			_spawned.append(prop);total_spawned += 1;made += 1

func _ensure_local_quota(focus: Node3D, target: int, keep_radius: float, spawn_min: float, spawn_max: float, batch_limit: int, player_priority: bool) -> void :
	if focus == null or not is_instance_valid(focus): return
	var max_tier: = _focus_level(focus)
	var missing: = maxi(0, target - _count_near_edible(focus, keep_radius, max_tier))
	var to_spawn: = mini(missing, batch_limit)
	if player_priority and to_spawn > 0: _make_room_for_player(to_spawn, max_tier)
	var made: = 0
	var guard: = 0
	while made < to_spawn and _active_count() < ARENA_MAX_ACTIVE_ITEMS and guard < to_spawn * 28 + 40:
		guard += 1
		var profile: = _random_profile(max_tier)
		var placement: = _road_position_for_focus(focus.global_position, profile, spawn_min, spawn_max)
		if placement.is_empty(): continue
		var prop: = _spawn_profile(profile, placement)
		if prop != null:
			_spawned.append(prop);total_spawned += 1;made += 1

func _make_room_for_player(required_slots: int, player_tier: int) -> void :
	var shortage: = maxi(0, _active_count() + required_slots - ARENA_MAX_ACTIVE_ITEMS)
	if shortage <= 0 or _focus == null or not is_instance_valid(_focus): return
	var candidates: Array = []
	for node_value in _spawned:
		if not is_instance_valid(node_value): continue
		var node: = node_value as Node3D
		if not bool(node.get("active")) or int(node.get("state")) != 0: continue
		var distance: = node.global_position.distance_to(_focus.global_position)
		var locked: = int(node.get("required_level")) > player_tier
		if not locked and distance <= PLAYER_TOTAL_KEEP_M: continue
		candidates.append({"node": node, "score": distance + (10000.0 if locked else 0.0)})
	candidates.sort_custom( func(a, b): return float(a["score"]) > float(b["score"]))
	for candidate in candidates:
		if shortage <= 0: break
		_retire_sparse_prop(candidate["node"])
		shortage -= 1

func get_arena_active_limit() -> int:
	return ARENA_MAX_ACTIVE_ITEMS
