extends "res://scripts/tornado_battle_manager_v4.gd"

const ENEMY_V5_SCRIPT = preload("res://scripts/tornado_enemy_v5.gd")
const RELOCATION_NPC_GAP_M: = 72.0
const PLAYER_RESPAWN_DELAY_SECONDS: = 2.0
const PLAYER_RESPAWN_GRACE_SECONDS: = 1.5

var player_spawn_grace_clock: = 0.0

func _physics_process(delta: float) -> void :
	player_spawn_grace_clock = maxf(0.0, player_spawn_grace_clock - delta)
	super._physics_process(delta)

func _spawn_enemy(index_hint: int) -> void :
	var enemy = ENEMY_V5_SCRIPT.new()
	enemy.name = "EnemyTornado_%03d" % spawn_serial
	add_child(enemy)
	var preferred: = _distributed_spawn_for_slot(enemies.size(), _target_enemy_count())
	var spawn: = _safe_position(preferred)
	var initial_mass: = _starting_mass_for_slot(index_hint)
	enemy.call("configure", spawn_serial, player, city, spawn, initial_mass, arena_limit, obstacle_grid, OBSTACLE_CELL_M)
	enemy.defeated.connect(_on_actor_defeated)
	enemies.append(enemy)
	spawn_serial += 1

func _population_destination() -> Vector3:
	if player == null or not is_instance_valid(player):
		return Vector3.INF
	var camera: = get_viewport().get_camera_3d()
	for _attempt in range(28):
		var angle: = rng.randf_range(0.0, TAU)
		var distance: = rng.randf_range(RELOCATE_MIN_M, RELOCATE_MAX_M)
		var preferred: Vector3 = player.global_position + Vector3(cos(angle) * distance, 0.0, sin(angle) * distance)
		var spawn: = _safe_position(preferred)
		spawn.y = 0.18
		if Vector2(spawn.x, spawn.z).distance_to(Vector2(player.global_position.x, player.global_position.z)) < RELOCATE_MIN_M * 0.82:
			continue
		if not _position_clear(spawn, 1.2):
			continue
		if camera != null and is_instance_valid(camera) and camera.is_position_in_frustum(spawn):
			continue
		if _destination_near_existing_enemy(spawn, RELOCATION_NPC_GAP_M):
			continue
		return spawn
	return Vector3.INF

func _destination_near_existing_enemy(position: Vector3, gap: float) -> bool:
	var gap_sq: = gap * gap
	for enemy in enemies:
		if not is_instance_valid(enemy) or not enemy.has_method("is_combat_alive") or not bool(enemy.call("is_combat_alive")):
			continue
		var offset: Vector3 = enemy.global_position - position
		offset.y = 0.0
		if offset.length_squared() < gap_sq:
			return true
	return false

func _apply_pair_contact(a, b, delta: float) -> void :
	if _actor_spawn_protected(a) or _actor_spawn_protected(b):
		return
	super._apply_pair_contact(a, b, delta)

func _actor_spawn_protected(actor) -> bool:
	if actor == null or not is_instance_valid(actor):
		return false
	if actor == player and player_spawn_grace_clock > 0.0:
		return true
	return actor.has_method("is_spawn_protected") and bool(actor.call("is_spawn_protected"))

func _on_actor_defeated(victim, killer) -> void :
	if victim != null and is_instance_valid(victim):
		_release_owned_world_objects(victim)
	super._on_actor_defeated(victim, killer)

func _respawn_player_later() -> void :
	await get_tree().create_timer(PLAYER_RESPAWN_DELAY_SECONDS).timeout
	if player == null or not is_instance_valid(player):
		return
	var spawn: = _safe_position(Vector3(rng.randf_range(-260.0, 260.0), 0.18, rng.randf_range(-260.0, 260.0)))
	player.call("reset_after_defeat", spawn, PLAYER_START_MASS_V4)
	player_spawn_grace_clock = PLAYER_RESPAWN_GRACE_SECONDS
	_sync_shared_props()
	print("VORTEX_PLAYER_RESPAWN_GRACE_READY seconds=%.1f" % PLAYER_RESPAWN_GRACE_SECONDS)

func _release_owned_world_objects(owner) -> void :
	if city == null or not is_instance_valid(city) or not city.has_method("get_props"):
		return
	var released: = 0
	var props_snapshot: Array = (city.call("get_props") as Array).duplicate()
	for prop in props_snapshot:
		if not is_instance_valid(prop) or not prop.has_method("release_from_defeated_owner"):
			continue
		if bool(prop.call("release_from_defeated_owner", owner)):
			released += 1
	if released > 0:
		print("TORNADO_DEFEAT_RELEASED_PROPS owner=%s released=%d" % [str(owner.call("get_actor_name")) if owner.has_method("get_actor_name") else "storm", released])

func uses_safe_owned_prop_release() -> bool:
	return true
func uses_true_spawn_grace() -> bool:
	return true
func uses_player_respawn_grace() -> bool:
	return true
func uses_hidden_population_relocation() -> bool:
	return true
