extends "res://scripts/tornado_enemy_v5.gd"

const DEFEAT_LOOT_SCAN_M := 150.0

func _choose_behavior() -> void:
	if spawn_grace_clock > 0.0:
		super._choose_behavior(); return
	var threat := _nearest_rival_by_ratio(THREAT_SCAN_M, FLEE_RATIO, true)
	if threat == null:
		var loot := _nearest_defeat_loot(DEFEAT_LOOT_SCAN_M)
		if loot != null:
			behavior_mode = "food"
			food_target = loot
			rival_target = null
			behavior_target = loot.global_position
			return
	super._choose_behavior()

func _nearest_defeat_loot(max_distance: float) -> Node3D:
	var best: Node3D = null
	var best_sq := max_distance * max_distance
	for value in nearby_props:
		if value == null or not is_instance_valid(value) or not (value is Node3D): continue
		var prop := value as Node3D
		if not bool(prop.get_meta("arena_defeat_loot", false)): continue
		if not bool(prop.get("active")) or int(prop.get("state")) != 0: continue
		if int(prop.get("required_level")) > get_level(): continue
		var offset := prop.global_position - global_position; offset.y = 0.0
		var dist_sq := offset.length_squared()
		if dist_sq >= best_sq: continue
		best = prop; best_sq = dist_sq
	return best

func prioritizes_defeat_loot() -> bool:
	return true
