extends "res://scripts/tornado_battle_manager_v5.gd"

const ENEMY_V6_SCRIPT = preload("res://scripts/tornado_enemy_v6.gd")

const KILL_SCORE_BASE: = 120
const KILL_SCORE_MASS_SCALE: = 3.2

var player_respawn_pending: = false

func _spawn_enemy(index_hint: int) -> void :
	var enemy = ENEMY_V6_SCRIPT.new()
	enemy.name = "EnemyTornado_%03d" % spawn_serial
	add_child(enemy)
	var preferred: = _distributed_spawn_for_slot(enemies.size(), _target_enemy_count())
	var spawn: = _safe_position(preferred)
	var initial_mass: = _starting_mass_for_slot(index_hint)
	enemy.call("configure", spawn_serial, player, city, spawn, initial_mass, arena_limit, obstacle_grid, OBSTACLE_CELL_M)
	enemy.defeated.connect(_on_actor_defeated)
	enemies.append(enemy)
	spawn_serial += 1

func _on_actor_defeated(victim, killer) -> void :
	if victim == null or not is_instance_valid(victim):
		return
	if victim == player:
		if player_respawn_pending:
			return
		player_respawn_pending = true
	else:
		var guard_id: = int(victim.get_instance_id())
		if bool(respawn_pending.get(guard_id, false)):
			return
		respawn_pending[guard_id] = true

	_release_owned_world_objects(victim)
	var victim_mass: = float(victim.call("get_mass")) if victim.has_method("get_mass") else 0.0
	var reward_score: = KILL_SCORE_BASE + int(round(victim_mass * KILL_SCORE_MASS_SCALE))
	var loot_pieces: = _spawn_shared_defeat_loot(victim.global_position, victim_mass)
	if killer != null and is_instance_valid(killer) and killer != victim and killer.has_method("add_score"):
		killer.call("add_score", reward_score)
		killer.call("register_kill")

	if victim == player:
		if battle_hud != null and is_instance_valid(battle_hud):
			var killer_name: = str(killer.call("get_actor_name")) if killer != null and is_instance_valid(killer) and killer.has_method("get_actor_name") else "风暴"
			battle_hud.call("show_event", "被 %s 击散 · 残骸已掉落 · 2秒后重组" % killer_name)
		_respawn_player_later()
		return

	if battle_hud != null and is_instance_valid(battle_hud) and killer == player:
		battle_hud.call("show_event", "击败 %s  +%d评分 · 爆出%d份残骸" % [str(victim.call("get_actor_name")), reward_score, loot_pieces])
	var dead_index: = int(victim.get("enemy_index")) if victim.get("enemy_index") != null else 0
	print("TORNADO_ENEMY_DEFEATED_ARENA name=%s score=%d loot=%d retained=1 direct_mass_reward=0 duplicate_guard=1" % [str(victim.call("get_actor_name")), reward_score, loot_pieces])
	_respawn_enemy_node_later(victim, dead_index)

func _respawn_player_later() -> void :
	await get_tree().create_timer(PLAYER_RESPAWN_DELAY_SECONDS).timeout
	if player == null or not is_instance_valid(player):
		player_respawn_pending = false
		return
	var spawn: = _safe_position(Vector3(rng.randf_range(-260.0, 260.0), 0.18, rng.randf_range(-260.0, 260.0)))
	player.call("reset_after_defeat", spawn, PLAYER_START_MASS_V4)
	player_spawn_grace_clock = PLAYER_RESPAWN_GRACE_SECONDS
	player_respawn_pending = false
	_sync_shared_props()
	print("VORTEX_PLAYER_RESPAWN_GRACE_READY seconds=%.1f duplicate_guard=1" % PLAYER_RESPAWN_GRACE_SECONDS)

func _spawn_shared_defeat_loot(world_position: Vector3, victim_mass: float) -> int:
	if sparse_runtime == null or not is_instance_valid(sparse_runtime):
		return 0
	if not sparse_runtime.has_method("spawn_defeat_loot"):
		return 0
	return int(sparse_runtime.call("spawn_defeat_loot", world_position, victim_mass))

func uses_contested_defeat_loot() -> bool:
	return true
func uses_direct_kill_mass_reward() -> bool:
	return false
func uses_loot_contesting_ai() -> bool:
	return true
func uses_single_settlement_death() -> bool:
	return true
