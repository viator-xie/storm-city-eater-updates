extends "res://scripts/standalone_level_safe_boot_v3.gd"

const TOKYO_REAL_CITY_ARENA_SCRIPT = preload("res://scripts/tokyo_real_city_arena.gd")

func _ready():
	if route_mode != "city":
		super._ready()
		return

	process_mode = Node.PROCESS_MODE_ALWAYS
	set_process(true)
	set_physics_process(true)
	mode = route_mode
	run_state = RunState.INTRO
	storm_fx = null

	_ensure_tokyo_runtimes()
	_setup_environment()
	print("ALPHA51_REENTRY_LIGHT_READY mode=%s world=%d sun=%d" % [mode, 1 if get_node_or_null("WorldEnvironment") != null else 0, 1 if get_node_or_null("StormDaylight") != null else 0])

	map_node = TOKYO_REAL_CITY_ARENA_SCRIPT.new()
	map_node.name = "BigCity"
	add_child(map_node)
	map_node.rng.seed = 20260903
	_prop_count = map_node.build()

	if _tokyo_world_items_runtime != null and _tokyo_world_items_runtime.has_method("bind_city"):
		_tokyo_world_items_runtime.call("bind_city", map_node, null)

	_boot_tornado_and_gameplay()
	if map_node != null and map_node.has_method("get_safe_spawn_position"):
		tornado.global_position = map_node.call("get_safe_spawn_position", tornado.global_position)
	if _tokyo_collision_runtime != null and _tokyo_collision_runtime.has_method("bind_city"):
		_tokyo_collision_runtime.call("bind_city", map_node, tornado)
	_start_vortex_arena()
	_install_runtime_update_button()
	print("TOKYO_ARENA_CONCURRENT_CITY_READY small_props=1 buildings=1")
