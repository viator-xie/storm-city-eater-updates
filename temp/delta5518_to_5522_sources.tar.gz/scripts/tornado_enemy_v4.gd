extends "res://scripts/tornado_enemy_v3.gd"

const INITIAL_GRACE_SECONDS: = 0.9
const RESPAWN_GRACE_SECONDS: = 1.5
const PASSIVE_SEPARATION_SCALE: = 0.76
const PASSIVE_SEPARATION_MAX_PUSH: = 0.12
const FULL_VISUAL_DISTANCE_M: = 620.0
const VISUAL_LOD_TICK_SECONDS: = 0.35

var spawn_grace_clock: = 0.0
var health_text: Label3D = null
var _last_health_percent: = -1
var _visual_lod_clock: = 0.0
var _full_visual_active: = true

func _ready() -> void :
	super._ready();_build_health_text();_visual_lod_clock = 0.0

func _build_health_text() -> void :
	if health_bar_root == null or not is_instance_valid(health_bar_root): return
	health_text = Label3D.new();health_text.name = "HealthText";health_text.text = "HP 100%"
	health_text.font_size = 28;health_text.outline_size = 7
	health_text.modulate = Color(0.96, 0.97, 0.98, 1.0);health_text.outline_modulate = Color(0.02, 0.025, 0.03, 0.92)
	health_text.position = Vector3(0.0, 0.33, 0.0);health_text.billboard = BaseMaterial3D.BILLBOARD_ENABLED;health_text.fixed_size = true
	health_bar_root.add_child(health_text)

func configure(index: int, target_player: Node3D, city_node: Node, spawn_position: Vector3, initial_mass: float, limit: float, shared_obstacle_grid: Dictionary = {}, shared_obstacle_cell: = 96.0) -> void :
	super.configure(index, target_player, city_node, spawn_position, initial_mass, limit, shared_obstacle_grid, shared_obstacle_cell)
	spawn_grace_clock = INITIAL_GRACE_SECONDS;_last_health_percent = -1;_visual_lod_clock = 0.0

func _physics_process(delta):
	spawn_grace_clock = maxf(0.0, spawn_grace_clock - delta);_visual_lod_clock -= delta
	if _visual_lod_clock <= 0.0:
		_visual_lod_clock = VISUAL_LOD_TICK_SECONDS;_update_visual_lod()
	if behavior_mode == "food" and food_target != null and is_instance_valid(food_target):
		if not bool(food_target.get("active")) or int(food_target.get("state")) != 0 or int(food_target.get("required_level")) > level:
			food_target = null;behavior_mode = "wander";decision_clock = 0.0
	super._physics_process(delta);_apply_passive_separation(delta)

func _update_visual_lod() -> void :
	if visual == null or not is_instance_valid(visual): return
	var should_show: = combat_alive
	if should_show and player_ref != null and is_instance_valid(player_ref):
		var offset: = global_position - player_ref.global_position;offset.y = 0.0
		should_show = offset.length_squared() <= FULL_VISUAL_DISTANCE_M * FULL_VISUAL_DISTANCE_M
	if should_show == _full_visual_active: return
	_full_visual_active = should_show;visual.visible = should_show;visual.set_process(should_show)
	var emitters_value = visual.get("particle_emitters")
	if emitters_value is Array:
		for emitter in emitters_value as Array:
			if emitter is GPUParticles3D and is_instance_valid(emitter): (emitter as GPUParticles3D).emitting = should_show
	if is_instance_valid(ground_marker): ground_marker.visible = should_show

func _apply_passive_separation(delta: float) -> void :
	if not combat_alive or spawn_grace_clock > 0.0 or behavior_mode == "chase": return
	var steer: = Vector3.ZERO; var contributors: = 0
	for value in arena_peers:
		if value == self or not (value is Node3D) or not is_instance_valid(value): continue
		var rival: = value as Node3D
		if rival.has_method("is_combat_alive") and not bool(rival.call("is_combat_alive")): continue
		var offset: = global_position - rival.global_position;offset.y = 0.0; var distance: = offset.length()
		if distance <= 0.001: continue
		var rival_radius: = float(rival.call("get_visual_radius")) if rival.has_method("get_visual_radius") else 4.5
		var desired_gap: = maxf(4.0, (visual_radius + rival_radius) * PASSIVE_SEPARATION_SCALE)
		if distance >= desired_gap: continue
		steer += offset.normalized() * (1.0 - distance / desired_gap);contributors += 1
	if contributors <= 0 or steer.length_squared() <= 0.0001: return
	var push: = minf(PASSIVE_SEPARATION_MAX_PUSH, delta * (1.8 + float(contributors) * 0.45));add_combat_push(steer.normalized(), push)

func _choose_behavior() -> void :
	if spawn_grace_clock > 0.0:
		chase_timer = 0.0;rival_target = null
		var food: = _nearest_edible_prop(100.0)
		if food != null:
			behavior_mode = "food";food_target = food;behavior_target = food.global_position
		else:
			behavior_mode = "wander";food_target = null
		return
	super._choose_behavior()

func take_combat_damage(damage: float, mass_loss: float, attacker = null) -> void :
	if spawn_grace_clock > 0.0: return
	super.take_combat_damage(damage, mass_loss, attacker)
func add_combat_push(direction: Vector3, strength: float) -> void :
	if spawn_grace_clock > 0.0: return
	super.add_combat_push(direction, strength)
func _update_health_bar() -> void :
	super._update_health_bar()
	if health_text == null or not is_instance_valid(health_text): return
	var ratio: = clampf(health / maxf(1.0, max_health), 0.0, 1.0); var percent: = int(round(ratio * 100.0))
	if percent != _last_health_percent:
		_last_health_percent = percent;health_text.text = "%s   HP %d%%" % [actor_name, percent]
	health_text.visible = health_bar_root != null and is_instance_valid(health_bar_root) and health_bar_root.visible
func reset_after_defeat(spawn_position: Vector3, restart_mass: = 12.0) -> void :
	super.reset_after_defeat(spawn_position, restart_mass)
	spawn_grace_clock = RESPAWN_GRACE_SECONDS;_last_health_percent = -1;_visual_lod_clock = 0.0;_update_visual_lod();_update_health_bar()
func has_world_health_bar() -> bool: return health_bar_root != null and is_instance_valid(health_bar_root) and health_bar_fill != null and is_instance_valid(health_bar_fill)
func has_numeric_health_display() -> bool: return health_text != null and is_instance_valid(health_text)
func is_spawn_protected() -> bool: return spawn_grace_clock > 0.0
func uses_population_visual_lod() -> bool: return true
