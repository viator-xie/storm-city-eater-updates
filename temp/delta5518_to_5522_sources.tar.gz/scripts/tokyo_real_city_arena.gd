extends "res://scripts/tokyo_real_city_baked.gd"

const ARENA_LIFTABLE_BUILDING_SCRIPT = preload("res://scripts/tokyo_liftable_building_battle.gd")

func _spawn_liftable_building(center: Vector2, height: float, profile: Dictionary) -> void :
	var size_value: Vector3 = profile.get("size", Vector3(6.0, height, 6.0))
	var required_level: = int(profile.get("level", 4))
	var mass_value: = float(profile.get("mass", 30.0))
	var display_name: = str(profile.get("name", "小型建筑"))
	var mesh: = BoxMesh.new()
	mesh.size = size_value
	mesh.material = _liftable_material
	var prop = ARENA_LIFTABLE_BUILDING_SCRIPT.new()
	prop.name = "LiftableBuilding_%d" % liftable_building_count
	add_child(prop)
	prop.setup_building(mesh, Vector3(center.x, height * 0.5, center.y), size_value, required_level, mass_value, display_name)
	props.append(prop)
	prop_count += 1
	liftable_building_count += 1
	if required_level == 4:
		liftable_tier4_count += 1
	else:
		liftable_tier5_count += 1
