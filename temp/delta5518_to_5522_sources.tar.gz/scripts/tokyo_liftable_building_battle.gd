extends "res://scripts/tokyo_liftable_building_arena.gd"

const BUILDING_SCORE_PER_MASS: = 1.35

func _consume() -> void :
	if not active:
		return
	active = false
	state = 5
	var owner = tornado_ref
	if owner != null and is_instance_valid(owner):
		owner.call("absorb_prop", mass_value, display_name, is_goal, global_position)
		if owner.has_method("add_score"):
			owner.call("add_score", maxi(1, int(round(mass_value * BUILDING_SCORE_PER_MASS))))
	queue_free()

func is_scored_arena_building() -> bool:
	return true
