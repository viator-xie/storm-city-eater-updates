extends "res://scripts/arena_shared_wind_prop.gd"

const BUILDING_COLLISION_LAYER: = 1 << 2

var _ground_body: StaticBody3D
var _ground_shape: CollisionShape3D
var building_size: = Vector3.ONE

func setup_building(mesh: Mesh, world_position: Vector3, size_value: Vector3, level: int, value: float, name_text: String) -> void :
	building_size = size_value
	setup(mesh, world_position, Vector3.ZERO, level, value, name_text, false, Vector3.ONE)
	collision_radius = clampf(maxf(size_value.x, size_value.z) * 0.48, 1.5, 7.0)
	_ground_body = StaticBody3D.new()
	_ground_body.name = "GroundedBuildingCollision"
	_ground_body.collision_layer = BUILDING_COLLISION_LAYER
	_ground_body.collision_mask = 0
	_ground_body.set_meta("tokyo_liftable_building", true)
	_ground_shape = CollisionShape3D.new()
	var shape: = BoxShape3D.new()
	shape.size = size_value
	_ground_shape.shape = shape
	_ground_body.add_child(_ground_shape)
	add_child(_ground_body)

func begin_pull(tornado) -> void :
	if not active or state != 0:
		return
	_disable_ground_collision()
	super.begin_pull(tornado)

func _disable_ground_collision() -> void :
	if is_instance_valid(_ground_body):
		_ground_body.collision_layer = 0
		_ground_body.collision_mask = 0
	if is_instance_valid(_ground_shape):
		_ground_shape.disabled = true

func _enable_ground_collision() -> void :
	if is_instance_valid(_ground_body):
		_ground_body.collision_layer = BUILDING_COLLISION_LAYER
		_ground_body.collision_mask = 0
	if is_instance_valid(_ground_shape):
		_ground_shape.disabled = false

func release_from_defeated_owner(actor) -> bool:
	var released: = super.release_from_defeated_owner(actor)
	if released:
		_enable_ground_collision()
	return released

func is_whole_building_target() -> bool:
	return true
func is_arena_concurrent_building() -> bool:
	return true
